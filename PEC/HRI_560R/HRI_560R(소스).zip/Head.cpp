//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

//---------------------------------------------------------------------------
#include "Head.h"
#include "Rail.h"

#include "SLogUnit.h"
#include "SMInterfaceUnit.h"
#include "UtilDefine.h"
#include "PstnMan.h"
#include "OptionMan.h"
#include "VisnComUnit.h"
#include "UserINI.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)
//sun MT.AllDone
//sun AT.AllDone�����.
//---------------------------------------------------------------------------
CHead  HED;

enum EN_INSP_DIRC{idLeftTop = 0 , idLeftBtm = 1 };
EN_INSP_DIRC HEAD_INSP_DIRECTION = idLeftBtm ;

int GetRightStartCol() //Col�� Ȧ�� ���϶� ������ ���ٸ��� �Ҵ� �Ǿ� �Ѵ�.
{
    int iColCnt = (OM.DevInfo.iColCnt % 2) ? OM.DevInfo.iColCnt + 1 : OM.DevInfo.iColCnt ;

    iColCnt = iColCnt /2 ;

    return iColCnt ;
}

int GetVtlColCnt ()
{
    //2���� �ص尡 ����������.. Ȧ�� �̸�
    int iColVtlCnt = (OM.DevInfo.iColCnt % 2) ? OM.DevInfo.iColCnt  : OM.DevInfo.iColCnt + 1 ;

    int iColCnt = /*(OM.CmnOptn.bCam1Skip||OM.CmnOptn.bCam2Skip) ? iColVtlCnt/2 :*/ OM.DevInfo.iColCnt ;

    int iRet = iColCnt ;
    if(OM.DevInfo.iColInspCnt) {
        iRet = (OM.DevInfo.iColCnt % OM.DevInfo.iColInspCnt) ?
              ((iColCnt / OM.DevInfo.iColInspCnt) * OM.DevInfo.iColInspCnt + OM.DevInfo.iColInspCnt) :
              ((iColCnt / OM.DevInfo.iColInspCnt) * OM.DevInfo.iColInspCnt) ;
    }
    return iRet ;
}
int GetVtlRowCnt () //������ ������� ������ ������ RowCnt.
{                  //Ȯ��.
    int iRet = 0 ;
    if(OM.DevInfo.iRowInspCnt) {
        iRet = (OM.DevInfo.iRowCnt % OM.DevInfo.iRowInspCnt) ?
              ((OM.DevInfo.iRowCnt / OM.DevInfo.iRowInspCnt) * OM.DevInfo.iRowInspCnt + OM.DevInfo.iRowInspCnt) :
              ((OM.DevInfo.iRowCnt / OM.DevInfo.iRowInspCnt) * OM.DevInfo.iRowInspCnt) ;

    }
    return iRet ;
}
bool GetLtToRt(int r)
{
    //�̷��� �ϸ� ����̽� �V�� �Ҷ� �˻� ������ ���� ��������.
    //if(HEAD_INSP_DIRECTION == idLeftBtm) return !((OM.DevInfo.iRowInspCnt ? r/OM.DevInfo.iRowInspCnt : r) %2);
    //else                                 return  ((OM.DevInfo.iRowInspCnt ? r/OM.DevInfo.iRowInspCnt : r) %2);

    //���� ������ ������.
    int br ;

    if(HEAD_INSP_DIRECTION == idLeftTop) br = r                         ;
    else                                 br = OM.DevInfo.iRowCnt - r -1 ;

    return !((OM.DevInfo.iRowInspCnt ? br/OM.DevInfo.iRowInspCnt : br) %2);
}

/*
double GetLeftPos ()
{
    double dRet = (PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkStart) + (OM.DevInfo.iColInspCnt - 1) * OM.DevInfo.dColPitch / 2.0) ;
    return dRet ;
}
double GetRightPos ()
{
    int iColOneGrCnt = OM.DevInfo.iColGrCnt ? OM.DevInfo.iColCnt / OM.DevInfo.iColGrCnt : 0;
    int iRowOneGrCnt = OM.DevInfo.iRowGrCnt ? OM.DevInfo.iRowCnt / OM.DevInfo.iRowGrCnt : 0;
    double dRet = PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkStart) +
                  OM.DevInfo.dColPitch * GetVtlColCnt() +
                  (OM.DevInfo.dColGrGap - OM.DevInfo.dColPitch) *        (iColOneGrCnt ? (GetVtlColCnt()/iColOneGrCnt) : 0) +
                  (OM.DevInfo.iColInspCnt - 1) * OM.DevInfo.dColPitch / 2.0 ;
    return dRet ;
}

double GetLeftPosCt()
{
    double dRet = PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkStart) ;
    return dRet ;
}

double GetRightPosCt()
{
    int iColOneGrCnt = OM.DevInfo.iColGrCnt ? OM.DevInfo.iColCnt / OM.DevInfo.iColGrCnt : 0;
    int iRowOneGrCnt = OM.DevInfo.iRowGrCnt ? OM.DevInfo.iRowCnt / OM.DevInfo.iRowGrCnt : 0;

    double dRet = PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkStart) + OM.DevInfo.dColPitch * GetVtlColCnt() +
                  (OM.DevInfo.dColGrGap - OM.DevInfo.dColPitch) * (iColOneGrCnt ? (GetVtlColCnt()/iColOneGrCnt) : 0) -
                  OM.DevInfo.iColInspCnt * OM.DevInfo.dColPitch ;
                  //(OM.DevOptn.iColInspCnt - 1) * OM.DevInfo.dColPitch / 2.0 ;
    return dRet ;
}

bool GetLtToRt(int r)
{
//    if(HEAD_INSP_DIRECTION == idLeftTop ||
//       HEAD_INSP_DIRECTION == idLeftBtm) return !((OM.DevInfo.iRowInspCnt ? r/OM.DevInfo.iRowInspCnt : r) %2);
    if(HEAD_INSP_DIRECTION == idLeftBtm) return !((OM.DevInfo.iRowInspCnt ? r/OM.DevInfo.iRowInspCnt : r) %2);
    else                            return  ((OM.DevInfo.iRowInspCnt ? r/OM.DevInfo.iRowInspCnt : r) %2);
}

*/


CHead::CHead(void)
{
    m_sPartName = "Head " ;
    LoadDpAray();

    Reset();
}

void CHead::LoadDpAray()
{
    //Local Var.
    FILE       *fp;
    //Make Dir.
    AnsiString  DevName;
    AnsiString  Path = ExtractFilePath(Application -> ExeName) + "SeqData\\DispMap.DAT";

    //File Open.
    //File Open.
    fp = fopen(Path.c_str() , "rb");
    if (fp == NULL) {
        fp = fopen(Path.c_str() , "wb");
        return ;
    }

    //Read&Write.
    DpAray1.Load(true , fp , 1);
    DpAray2.Load(true , fp , 2);
    DpAray3.Load(true , fp , 3);

    fclose(fp);
}

void CHead::SaveDpAray()
{
    //Local Var.
    FILE       *fp;
    //Make Dir.
    AnsiString  DevName;
    AnsiString  Path =   ExtractFilePath(Application -> ExeName) + "SeqData\\DispMap.DAT";

    //File Open.
    fp = fopen(Path.c_str() , "wb");
    if (fp == NULL) return;

    //Read&Write.
    DpAray1.Load(false , fp , 1);
    DpAray2.Load(false , fp , 2);
    DpAray3.Load(false , fp , 3);

    fclose(fp);
}


void CHead::Reset()
{
    ResetTimer();

    //Init. Buffers
    memset(&Stat    , 0 , sizeof(SStat ));
    memset(&Step    , 0 , sizeof(SStep ));
    memset(&PreStep , 0 , sizeof(SStep ));
}

void CHead::ResetTimer()
{
    //Clear Timer.
    m_tmMain   .Clear();
    m_tmCycle  .Clear();
    m_tmHome   .Clear();
    m_tmToStop .Clear();
    m_tmToStart.Clear();
    m_tmTemp   .Clear();

}

CHead::~CHead (void)
{    
    //FormMain����  
}
bool CHead::FindChip( int &r , int &c )
{
    int r1 ;
    int c1 ;
    int r2 ;
    int c2 ;
    int r3 ;
    int c3 ;

    if(HEAD_INSP_DIRECTION == idLeftTop) {
        r = DM.ARAY[riVS1].GetMaxRow() ;
        c = DM.ARAY[riVS1].GetMaxCol() ;

        r1 = DM.ARAY[riVS1].GetMaxRow() ;
        c1 = DM.ARAY[riVS1].GetMaxCol() ;
        r2 = DM.ARAY[riVS2].GetMaxRow() ;
        c2 = DM.ARAY[riVS2].GetMaxCol() ;
        r3 = DM.ARAY[riVS3].GetMaxRow() ;
        c3 = DM.ARAY[riVS3].GetMaxCol() ;
        if(DM.ARAY[riVS1].CheckAllExist()&&DM.ARAY[riVS1].FindFrstRowCol(csUnkwn  , r1 , c1)) {r = r1 ; c = c1 ;}
        if(DM.ARAY[riVS2].CheckAllExist()&&DM.ARAY[riVS2].FindFrstRowCol(csUnkwn  , r2 , c2)) {if(r > r2) { r = r2 ; c = c2 ;}}
        if(DM.ARAY[riVS3].CheckAllExist()&&DM.ARAY[riVS3].FindFrstRowCol(csUnkwn  , r3 , c3)) {if(r > r3) { r = r3 ; c = c3 ;}}
    }

    if(HEAD_INSP_DIRECTION == idLeftBtm) {
        r = -1 ;
        c = -1 ;
        r1 = 0 ;
        c1 = DM.ARAY[riVS1].GetMaxCol() ;
        r2 = 0 ;
        c2 = DM.ARAY[riVS2].GetMaxCol() ;
        r3 = 0 ;
        c3 = DM.ARAY[riVS3].GetMaxCol() ;

        if(DM.ARAY[riVS1].CheckAllExist()&&DM.ARAY[riVS1].FindLastRowFrstCol(csUnkwn  , r1 , c1)) {r = r1 ; c = c1 ; }
        if(DM.ARAY[riVS2].CheckAllExist()&&DM.ARAY[riVS2].FindLastRowFrstCol(csUnkwn  , r2 , c2)) {if(r < r2) { r = r2 ; c = c2 ;}}
        if(DM.ARAY[riVS3].CheckAllExist()&&DM.ARAY[riVS3].FindLastRowFrstCol(csUnkwn  , r3 , c3)) {if(r < r3) { r = r3 ; c = c3 ;}}
        //r = DM.ARAY[riVS3].GetMaxRow() -r -1 ;
        //c = DM.ARAY[riVS3].GetMaxCol() -c -1 ;
    }

    if(r == -1 && c == -1) return false ;

    return true ;
}
/*
bool CHead::FindChip( int &r , int &c )
{
    int r1 ;
    int c1 ;
    int r2 ;
    int c2 ;
    int r3 ;
    int c3 ;

    if(HEAD_INSP_DIRECTION == idLeftTop) {
        r = DM.ARAY[riVS1].GetMaxRow() ;
        c = DM.ARAY[riVS1].GetMaxCol() ;

        r1 = DM.ARAY[riVS1].GetMaxRow() ;
        c1 = DM.ARAY[riVS1].GetMaxCol() ;
        r2 = DM.ARAY[riVS2].GetMaxRow() ;
        c2 = DM.ARAY[riVS2].GetMaxCol() ;
        r3 = DM.ARAY[riVS3].GetMaxRow() ;
        c3 = DM.ARAY[riVS3].GetMaxCol() ;
        if(DM.ARAY[riVS1].CheckAllExist()&&DM.ARAY[riVS1].FindFrstRowCol(csUnkwn  , r1 , c1)) {r = r1 ; c = c1 ;}
        if(DM.ARAY[riVS2].CheckAllExist()&&DM.ARAY[riVS2].FindFrstRowCol(csUnkwn  , r2 , c2)) {if(r > r2) { r = r2 ; c = c2 ;}}
        if(DM.ARAY[riVS3].CheckAllExist()&&DM.ARAY[riVS3].FindFrstRowCol(csUnkwn  , r3 , c3)) {if(r > r3) { r = r3 ; c = c3 ;}}
    }

    if(HEAD_INSP_DIRECTION == idLeftBtm) {
        r = -1 ;
        c = -1 ;
        r1 = 0 ;
        c1 = DM.ARAY[riVS1].GetMaxCol() ;
        r2 = 0 ;
        c2 = DM.ARAY[riVS2].GetMaxCol() ;
        r3 = 0 ;
        c3 = DM.ARAY[riVS3].GetMaxCol() ;

        if(DM.ARAY[riVS1].CheckAllExist()&&DM.ARAY[riVS1].FindLastRowFrstCol(csUnkwn  , r1 , c1)) {r = r1 ; c = c1 ; }
        if(DM.ARAY[riVS2].CheckAllExist()&&DM.ARAY[riVS2].FindLastRowFrstCol(csUnkwn  , r2 , c2)) {if(r < r2) { r = r2 ; c = c2 ;}}
        if(DM.ARAY[riVS3].CheckAllExist()&&DM.ARAY[riVS3].FindLastRowFrstCol(csUnkwn  , r3 , c3)) {if(r < r3) { r = r3 ; c = c3 ;}}
        r = DM.ARAY[riVS3].GetMaxRow() -r -1 ;
        c = DM.ARAY[riVS3].GetMaxCol() -c -1 ;
    }

    if(r == -1 && c == -1) return false ;

    return true ;
}
*/
//�޴��� ���۵��� ����.
/*
double CHead::GetMotrPosTable(EN_MOTR_ID _iMotr , int _iRow , int _iCol)
{
    int r , c ;
    double dStartYPos = 0.0 ;
    double dStartXPos = 0.0 ;
    double dYPos      ;
    double dXPos      ;

    r = OM.DevInfo.iRowInspCnt ? _iRow/OM.DevInfo.iRowInspCnt * OM.DevInfo.iRowInspCnt : _iRow ;
    c = OM.DevInfo.iColInspCnt ? _iCol/OM.DevInfo.iColInspCnt * OM.DevInfo.iColInspCnt : _iCol ;

    dStartXPos = PM.GetValue(_iMotr , pvWRK_XVsnWorkSttPs ) ;

    if     (_iMotr == miWK1_YVsn) dStartYPos = PM.GetValue(_iMotr , pvWK1_YVsnWorkSttPs ) ;
    else if(_iMotr == miWK2_YVsn) dStartYPos = PM.GetValue(_iMotr , pvWK2_YVsnWorkSttPs ) ;



    if(_iMotr != miWK1_YVsn && _iMotr != miWK2_YVsn && _iMotr != miWRK_XVsn) return MT_GetCmdPos(_iMotr) ;



    dXPos = dStartXPos + c * OM.DevInfo.dColPitch ;
    dYPos = dStartYPos + r * OM.DevInfo.dRowPitch ;

    if(OM.DevInfo.dColGrGap && OM.DevInfo.iColGrCnt) {
        dXPos = dXPos + (c / OM.DevInfo.iColGrCnt) * (OM.DevInfo.dColGrGap - OM.DevInfo.dColPitch) ;
    }

    if(OM.DevInfo.dRowGrGap && OM.DevInfo.iRowGrCnt) {
        dYPos = dYPos + (r / OM.DevInfo.iRowGrCnt) * (OM.DevInfo.dRowGrGap - OM.DevInfo.dRowPitch) ;
    }


    if     (_iMotr == miWK1_YVsn) return dYPos ;
    else if(_iMotr == miWK2_YVsn) return dYPos ;
    else if(_iMotr == miWRK_XVsn) return dXPos ;
}
*/

double CHead::GetMotrPos(EN_MOTR_ID _iMotr , EN_PSTN_ID _iPstnId )
{
    int r  , c  ,rr;
    const double dOfsforTrg = 5.0 ; //���� ���ͷ�Ʈ Ʈ���Ÿ� ���� �əV.
    double dStartYPos ;
    const bool bPkgCntr = false ;

    //���. �ö��� ����̶� ���� ����.
    FindChip( r , c ) ;
    //r = OM.DevInfo.iRowInspCnt ? r/OM.DevInfo.iRowInspCnt  * OM.DevInfo.iRowInspCnt  :  r ;

    bool bLeftToRight = GetLtToRt(r);

    dStartYPos = PM.GetValue(miWRK_YVsn , pvWRK_YVsnWorkStart ) ;

    //��ŸƮ �����ǰ� ���� ������ ����.
    double dXStartPos ;
    double dXEndPos   ;
    double dYPos      ;
    double dXOffsetWrkStt ;

/**/double dLeftPosCt  ;
/**/double dRightPosCt ;

    dLeftPosCt  = PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkStart ) ;
    dRightPosCt = PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkEnd   ) ;

    if(bLeftToRight) {
        dXStartPos = dLeftPosCt  - dOfsforTrg ;
        dXEndPos   = dRightPosCt + dOfsforTrg ;
    }
    else {
        dXStartPos = dRightPosCt + dOfsforTrg ;
        dXEndPos   = dLeftPosCt  - dOfsforTrg ;
    }

    dXOffsetWrkStt = dLeftPosCt  - dOfsforTrg ;

    if(HEAD_INSP_DIRECTION == idLeftTop) {
        rr    = r ;
        dYPos = dStartYPos +                                           //ù������ ���ϰ�.
                rr * OM.DevInfo.dRowPitch +    //�˻翭�� �����ؼ� �ش� �ο� ���� �Ÿ�����ؼ� ���ϰ�.
               //(OM.DevOptn.iRowInspCnt - 1) * OM.DevInfo.dRowPitch / 2.0 +  // ��Ŵ�
               (OM.DevInfo.dRowGrGap - OM.DevInfo.dRowPitch) * (OM.DevInfo.iRowGrCnt?(rr+1)/OM.DevInfo.iRowGrCnt : 0 ) ; //�׷� ���� ���� �ؼ� ����.
    }

    if(HEAD_INSP_DIRECTION == idLeftBtm) {
        rr    = OM.DevInfo.iRowCnt - r -1 ;
        dYPos = dStartYPos -                                           //ù������ ���ϰ�.
                rr * OM.DevInfo.dRowPitch -    //�˻翭�� �����ؼ� �ش� �ο� ���� �Ÿ�����ؼ� ���ϰ�.
               //(OM.DevOptn.iRowInspCnt - 1) * OM.DevInfo.dRowPitch / 2.0 +  // ��Ŵ�
               (OM.DevInfo.dRowGrGap - OM.DevInfo.dRowPitch) * (OM.DevInfo.iRowGrCnt?(rr+1)/OM.DevInfo.iRowGrCnt : 0 ) ; //�׷� ���� ���� �ؼ� ����.
    }


    double dPos = 0.0 ;

    if(_iMotr == miWRK_XVsn){
        switch(_iPstnId) {
            default                     : dPos = MT_GetCmdPos(_iMotr                         ); break ;
            case piWRK_XVsnWait         : dPos = PM.GetValue (_iMotr , pvWRK_XVsnWait        ); break ;
            case piWRK_XVsnWorkStart    : dPos = PM.GetValue (_iMotr , pvWRK_XVsnWorkStart   ); break ;
            case piWRK_XVsnWorkEnd      : dPos = PM.GetValue (_iMotr , pvWRK_XVsnWorkEnd     ); break ;
            case piWRK_XVsnTrgStt       : dPos = dXStartPos                                   ; break ;
            case piWRK_XVsnTrgEnd       : dPos = dXEndPos                                     ; break ;
        }
    }

    else if(_iMotr == miWRK_YVsn){
        switch(_iPstnId) {
            default                  : dPos = MT_GetCmdPos(_iMotr                         ); break ;
            case piWRK_YVsnWait      : dPos = PM.GetValue (_iMotr , pvWRK_YVsnWait        ); break ;
            case piWRK_YVsnWorkStart : dPos = PM.GetValue (_iMotr , pvWRK_YVsnWorkStart   ); break ;
            case piWRK_YVsnWork      : dPos = dYPos                                        ; break ;
        }
    }
    else {
        dPos = MT_GetCmdPos(_iMotr);
    }

    return dPos ;
}
//---------------------------------------------------------------------------
bool CHead::CheckSafe(EN_MOTR_ID _iMotr , EN_PSTN_ID _iPstnId)
{
    if(MT_CmprPos(_iMotr , GetMotrPos(_iMotr , _iPstnId)) ) return true ;

    AnsiString sMsg ;
    bool       bRet = true ;

    bool isFlprTurning = !MT_GetStop(miWK1_YFlp) ;
    bool isInsMoveing  = !AT_Done(aiWK1_Ins) ;

    if(_iMotr == miWRK_XVsn){
        if(isFlprTurning) { sMsg = "Fliper Moving" ; bRet = false ;}
        if(isInsMoveing ) { sMsg = "Insert Moving" ; bRet = false ;}
        switch(_iPstnId){
            default                  : break ;
            case piWRK_XVsnWait      : break ;
            case piWRK_XVsnWorkStart : break ;
            case piWRK_XVsnTrgStt    : break ;
            case piWRK_XVsnTrgEnd    : break ;
        }
    }

    else if(_iMotr == miWRK_YVsn){
        if(isFlprTurning) { sMsg = "Fliper Moving" ; bRet = false ;}
        if(isInsMoveing ) { sMsg = "Insert Moving" ; bRet = false ;}
        switch(_iPstnId){
            default                  : break ;
            case piWRK_YVsnWait      : break ;
            case piWRK_YVsnWorkStart : break ;
            case piWRK_YVsnWork      : break ;
        }
    }

    if(!bRet){
        Trace(MT_GetName(_iMotr).c_str(), sMsg.c_str());
        if(!Step.iCycle)FM_MsgOk(MT_GetName(_iMotr).c_str(),sMsg);
    }

    return bRet ;

//    else if(_iMotr == miWK2_YVsn){
//    }

//    else if(_iMotr == miWK1_ZVsn){
//    }
}

//---------------------------------------------------------------------------
bool CHead::CheckSafe(EN_ACTR_ID _iActr , bool _bFwd)
{
    if(AT_Complete(_iActr , _bFwd)) return true ;

    AnsiString sMsg ;
    bool       bRet = true ;

    if(!bRet){
        Trace(AT_GetName(_iActr).c_str(), sMsg.c_str());
        if(!Step.iCycle)FM_MsgOk(AT_GetName(_iActr).c_str(),sMsg);
    }

    return bRet ;
}
void CHead::SetTrgPos()
{
    int iTrgCnt      = OM.DevInfo.iColInspCnt ? GetVtlColCnt() / OM.DevInfo.iColInspCnt : 0;
    double dSttPos  ;
    double dTemp    ;
    int r,c ;

    AnsiString sTemp ;

    //ī�޶� ���ʸ� ���� ����ؾ���...
    dSttPos = PM.GetValue(miWRK_XVsn , pvWRK_XVsnWorkStart );

    double * dTrgPos = new double[iTrgCnt] ;

    FindChip(r,c );

    bool bLeftToRight = GetLtToRt(r);


    for(int i = 0 ; i < iTrgCnt ; i++) {
        dTemp = dSttPos +                    //ù������
                OM.DevInfo.dColPitch * OM.DevInfo.iColInspCnt * i +
               (OM.DevInfo.iColGrCnt ? (OM.DevInfo.dColGrGap - OM.DevInfo.dColPitch)* OM.DevInfo.iColInspCnt * (i + 1) / OM.DevInfo.iColGrCnt : 0 ) ;

          //Ʈ���� ������ ������ �ɼ�. ���� �ӵ��� ���� �̹��� �и�.
          if(bLeftToRight) dTrgPos[i] = dTemp - OM.MstOptn.dTrigerOffset ;
          else             dTrgPos[iTrgCnt - 1 - i] = dTemp + OM.MstOptn.dTrigerOffset ;



        sTemp += AnsiString(dTemp) + AnsiString(" ") ;
    }

    Trace("Trigger" , sTemp.c_str());



    MT_SetAxtTrgPos(miWRK_XVsn , iTrgCnt , dTrgPos , 2000 , true , false) ;
    //TODO :: 560��񿡼� �����ġ���� Ʈ���Ű� ������ ���󋚹���
    //_bOnLevel�� false�� �Է���. JS
    //_bOnLevel true  = High -> Low �� ������ �� Trigger ����.
    //_bOnLevel false = Low -> High �� �ö� �� Trigger ����.
    //�׽�Ʈ���� check ��. JS

    delete [] dTrgPos ;
}
/*
void CHead::SetTrgPos()
{
    int iTrgCnt      = OM.DevInfo.iColInspCnt ? GetVtlColCnt() / OM.DevInfo.iColInspCnt : 0;
    //int iColOneGrCnt = OM.DevInfo.iColGrCnt ? OM.DevInfo.iColCnt / OM.DevInfo.iColGrCnt : 0;
    //int iRowOneGrCnt = OM.DevInfo.iRowGrCnt ? OM.DevInfo.iRowCnt / OM.DevInfo.iRowGrCnt : 0;
    double dTemp    ;
    int r,c ;

    AnsiString sTemp ;

    double * dTrgPos = new double[iTrgCnt] ;



    FindChip(r,c );

    bool bLeftToRight = GetLtToRt(r);

    r = r/OM.DevInfo.iRowInspCnt * OM.DevInfo.iRowInspCnt ;

    for(int i = 0 ; i < iTrgCnt ; i++) {
        dTemp      = GetLeftPosCt() +                                                                                                                              //ù������
                      OM.DevInfo.dColPitch * OM.DevInfo.iColInspCnt * i +

                     (OM.DevInfo.iColGrCnt ? (OM.DevInfo.dColGrGap - OM.DevInfo.dColPitch)* OM.DevInfo.iColInspCnt * (i + 1) / OM.DevInfo.iColGrCnt : 0 ) ;

                                                                                                      //���� �˻� �׷캰��
                     //(OM.DevOptn.iColInspCnt * (i + 1) /
                     //(iColOneGrCnt ? OM.DevOptn.iColInspCnt/2 / iColOneGrCnt : 0) * (OM.DevInfo.dColGrGap - OM.DevInfo.dColPitch)) ;//�׷참 ���.
//        if(bLeftToRight) dTrgPos[i] = dTemp ;
//        else             dTrgPos[iTrgCnt - 1 - i] = dTemp ;

//Ʈ���� ������ ������ �ɼ�. ���� �ӵ��� ���� �̹��� �и�.
          if(bLeftToRight) dTrgPos[i] = dTemp - OM.MstOptn.dTrigerOffset ;
          else             dTrgPos[iTrgCnt - 1 - i] = dTemp + OM.MstOptn.dTrigerOffset ;



        sTemp += AnsiString(dTemp) + AnsiString(" ") ;
    }

    Trace("Trigger" , sTemp.c_str());



    MT_SetAxtTrgPos(miWRK_XVsn , iTrgCnt , dTrgPos , 1000 , true , true) ;

    delete [] dTrgPos ;
}
*/
void CHead::ResetTrgPos()
{
    MT_ResetAxtTrgPos(miWRK_XVsn) ;
}

bool CHead::MoveMotr(EN_MOTR_ID _iMotr , EN_PSTN_ID _iPstnId) // ���͸� �����϶� ���� �Լ�.
{
    if (!CheckSafe(_iMotr , _iPstnId)) return false;

    double dPosition = GetMotrPos(_iMotr , _iPstnId);

    if(Step.iCycle) return MT_GoAbsRun(_iMotr , dPosition);
    else            return MT_GoAbsMan(_iMotr , dPosition);
}

bool CHead::MoveActr(EN_ACTR_ID _iActr , bool _bFwd) //�Ǹ����� �����϶� ���� �Լ�.
{
    if (!CheckSafe(_iActr, _bFwd)) return false;

    return AT_MoveCyl(_iActr , _bFwd );
}

bool CHead::CycleHome()
{
    //Check Cycle Time Out.
    AnsiString sTemp ;
    if (m_tmCycle.OnDelay(Step.iHome && Step.iHome == PreStep.iHome && CheckStop() && !OM.MstOptn.bDebugMode , 8000 )) {
        EM_SetErr(eiHED_HomeTO);
        sTemp = sTemp.sprintf("%s TIMEOUT STATUS : Step.iHome=%02d" , __FUNC__ , Step.iHome );
        Trace(m_sPartName.c_str(),sTemp.c_str());
        Step.iCycle = 0 ;
        return true;
    }

    if(Step.iHome != PreStep.iHome) {
        sTemp = sTemp.sprintf("%s Step.iHome=%02d" , __FUNC__ , Step.iHome );
        Trace(m_sPartName.c_str(),sTemp.c_str());
    }

    PreStep.iHome = Step.iHome ;

    //if(Stat.bReqStop) {
    //    Step.iHome = 0;
    //    return true ;
    //}

    switch (Step.iHome) {

        default: sTemp = sTemp.sprintf("Cycle Default Clear %s Step.iCycle=%02d" , __FUNC__ , Step.iCycle );
                 //if(Step.iHome != PreStep.iHome)Trace(m_sPartName.c_str(), sTemp.c_str());
                 Step.iHome = 0 ;
                 return true ;

        case 10: if(!IO_GetX(xWR1_TurnDetect)){
                     EM_SetErr(eiWK1_FlipperMoveFail);
                     Step.iHome = 0;
                     return true;
                 }
                 MT_Reset(miWRK_XVsn);
                 MT_Reset(miWRK_YVsn);

                 MT_SetServo(miWRK_XVsn,true);
                 MT_SetServo(miWRK_YVsn,true);

                 //Ʈ���� ���� ����.
                 //SetTrgPos();
                 ResetTrgPos();

                 MT_DoHome(miWRK_YVsn) ;
                 MT_DoHome(miWRK_XVsn) ;
                 Step.iHome++ ;
                 return false ;

        case 11: if(!MT_GetHomeEnd(miWRK_YVsn))return false ;
                 if(!MT_GetHomeEnd(miWRK_XVsn))return false ;



                 MT_GoAbsMan(miWRK_YVsn , GetMotrPos(miWRK_YVsn , piWRK_YVsnWait));
                 MT_GoAbsMan(miWRK_XVsn , GetMotrPos(miWRK_XVsn , piWRK_XVsnWait));
                 Step.iHome++ ;
                 return false ;


        case 12: if(!MT_GoAbsMan(miWRK_YVsn , GetMotrPos(miWRK_YVsn , piWRK_YVsnWait))) return false ;
                 if(!MT_GoAbsMan(miWRK_XVsn , GetMotrPos(miWRK_XVsn , piWRK_XVsnWait))) return false ;

//                 if(!OM.CmnOptn.bVs1Skip) VC.SendReset(vrVisn1,true) ;
                 if(!OM.CmnOptn.bVs1Skip) VC.SendReset(vsVisn1) ;
                 if(!OM.CmnOptn.bVs2Skip) VC.SendReset(vsVisn2) ;
                 if(!OM.CmnOptn.bVs3Skip) VC.SendReset(vsVisn3) ;

                 //ResetTrgPos();

                 Step.iHome = 0 ;
                 return true ;
    }
}

bool CHead::ToStopCon(void) //��ž�� �ϱ� ���� ������ ���� �Լ�.
{
    Stat.bReqStop = true ;
    //During the auto run, do not stop.
    if (Step.iSeq) return false;

    Step.iToStop = 10 ;

    //Ok.
    return true;

}

bool CHead::ToStartCon(void) //��ŸƮ�� �ϱ� ���� ������ ���� �Լ�.
{
    Step.iToStart = 10 ;
    //Ok.
    return true;
}

bool CHead::ToStart(void) //��ŸƮ�� �ϱ� ���� �Լ�.
{
    //Check Time Out.
    if (m_tmToStart.OnDelay(Step.iToStart && !PreStep.iToStart == Step.iToStart && CheckStop() && !OM.MstOptn.bDebugMode , 5000)) EM_SetErr(eiHED_ToStartTO);

    AnsiString sTemp ;
    sTemp = sTemp.sprintf("Step.iToStart=%02d" , Step.iToStart );
    if(Step.iToStart != PreStep.iToStart) {
        Trace(m_sPartName.c_str(),sTemp.c_str());
    }

    PreStep.iToStart = Step.iToStart ;

    //���� ���μ��� ���� �̻��Ҷ�. Ŭ���� ���Ѽ� ÷���� �ϰ� �Ѵ�.
    bool bNotNormalEnded = false ;

    //Move Home.
    switch (Step.iToStart) {
        default: Step.iToStart = 0 ;
                 return true ;

        case 10: MoveMotr(miWRK_XVsn , piWRK_XVsnWait);
                 MoveMotr(miWRK_YVsn , piWRK_YVsnWait);

                 //if(DM.ARAY[riVS1].GetCntExist())DM.ARAY[riVS1].SetStat(csUnkwn) ;
                 //if(DM.ARAY[riWR1].GetCntExist())DM.ARAY[riWR1].ChangeStat(csWork,csUnkwn) ;
                 //
                 //if(DM.ARAY[riVS2].GetCntExist())DM.ARAY[riVS2].SetStat(csUnkwn) ;
                 //if(DM.ARAY[riWR2].GetCntExist())DM.ARAY[riWR2].ChangeStat(csWork,csUnkwn) ;
                 //
                 //if(DM.ARAY[riVS3].GetCntExist())DM.ARAY[riVS3].SetStat(csUnkwn) ;
                 //if(DM.ARAY[riWR3].GetCntExist())DM.ARAY[riWR3].ChangeStat(csWork,csUnkwn) ;

                 Step.iToStart ++ ;
                 return false ;

        case 11: if(!MoveMotr(miWRK_XVsn , piWRK_XVsnWait)) return false;
                 if(!MoveMotr(miWRK_YVsn , piWRK_YVsnWait)) return false;

                 Step.iToStart = 0 ;
                 return true ;
    }
}

bool CHead::ToStop(void) //��ž�� �ϱ� ���� �Լ�.
{
    //Check Time Out.
    if (m_tmToStop.OnDelay(Step.iToStop && !PreStep.iToStop == Step.iToStop && CheckStop() && !OM.MstOptn.bDebugMode , 8000)) EM_SetErr(eiHED_ToStopTO);

    AnsiString sTemp ;
    sTemp = sTemp.sprintf("Step.iToStop=%02d" , Step.iToStop );
    if(Step.iToStop != PreStep.iToStop) {
        Trace(m_sPartName.c_str(),sTemp.c_str());
    }

    PreStep.iToStop = Step.iToStop ;

    Stat.bReqStop = false ;

    //Move Home.
    switch (Step.iToStop) {
        default: Step.iToStop = 0;
                 return true ;

        case 10: //if(DM.ARAY[riVS1].GetCntExist())DM.ARAY[riVS1].SetStat(csUnkwn) ;
                 //if(DM.ARAY[riWR1].GetCntExist())DM.ARAY[riWR1].ChangeStat(csWork,csUnkwn) ;
                 //
                 //if(DM.ARAY[riVS2].GetCntExist())DM.ARAY[riVS2].SetStat(csUnkwn) ;
                 //if(DM.ARAY[riWR2].GetCntExist())DM.ARAY[riWR2].ChangeStat(csWork,csUnkwn) ;
                 //
                 //if(DM.ARAY[riVS3].GetCntExist())DM.ARAY[riVS3].SetStat(csUnkwn) ;
                 //if(DM.ARAY[riWR3].GetCntExist())DM.ARAY[riWR3].ChangeStat(csWork,csUnkwn) ;

                 Step.iToStop ++ ;
                 return false ;

        case 11: Step.iToStop = 0   ;
                 return true ;
    }
}

bool CHead::Autorun(void) //���䷱�׽ÿ� ��� Ÿ�� �Լ�.
{
    //Check Cycle Time Out.
    AnsiString sTemp ;
    sTemp = sTemp.sprintf("%s Step.iCycle=%02d" , __FUNC__ , Step.iCycle );
    if(Step.iSeq != PreStep.iSeq) {
        Trace(m_sPartName.c_str(),sTemp.c_str());
    }

    PreStep.iSeq = Step.iSeq ;

    //Check Error & Decide Step.
    if (Step.iSeq == 0) {
        if (Stat.bReqStop)return false ;

        if(EM_IsErr()) return false ;

//        bool isStrpExist     =  DM.ARAY[riPRB].GetCntExist (       ) ||
//                                RAL.GetSeqStep() == CRail::scIn      ||
//                                DM.ARAY[riLDR].GetCntStat  (csUnkwn) && OM.EqpOptn.bExistLoader ||
//                                DM.ARAY[riWK1].GetCntExist (       ) ;
        bool isNeedInspStart1 =  DM.ARAY[riVS1].GetCntStat  (csUnkwn) || DM.ARAY[riVS2].GetCntStat  (csUnkwn) || DM.ARAY[riVS3].GetCntStat  (csUnkwn) ;
        bool isNeedInspStart2 =  DM.ARAY[riWR1].GetCntExist (       ) || DM.ARAY[riWR2].GetCntExist (       ) || DM.ARAY[riWR3].GetCntExist (       ) ;
//        bool isWaitInsp1Pkg  =  DM.ARAY[riVS1].CheckAllStat(csEmpty) && isStrpExist ;
        bool isCycleMvPrb     =  DM.ARAY[riPRB].GetCntExist() && !DM.ARAY[riWR1].GetCntExist() ;

        bool isWK1Rdy     =  (MT_CmprPos (miWK1_YFlp , PM.GetValue(miWK1_YFlp,pvWK1_YFlpNormal )) ||
                              MT_CmprPos (miWK1_YFlp , PM.GetValue(miWK1_YFlp,pvWK1_YFlpInverse)))&& AT_Complete(aiWK1_FlpCmp,ccFwd);
//                            AT_Complete(aiWK1_Align,ccBwd) && AT_Complete(aiWK1_FlpCmp,ccFwd) && AT_Complete(aiWK1_Ins,ccBwd) && AT_Complete(aiWK1_Stopper,ccFwd) ;

        bool isWK1Ready      = (DM.ARAY[riVS1].GetCntStat(csUnkwn) &&  isWK1Rdy                         ) || !DM.ARAY[riWR1].GetCntExist() ;
        bool isWK2Ready      = DM.ARAY[riVS2].GetCntStat(csUnkwn) || !DM.ARAY[riWR2].GetCntExist() ;
        bool isWK3Ready      = DM.ARAY[riVS3].GetCntStat(csUnkwn) || !DM.ARAY[riWR3].GetCntExist() ;

//        bool isCycleInsp     =  isNeedInspStart && !isWaitInsp1Pkg && isWK1Ready && isWK2Ready ;
//        bool isCycleInsp     =  isNeedInspStart1 && isNeedInspStart2 && (isWK1Ready ||( isWK2Ready && isWK3Ready)) &&
        bool isCycleInsp     =  isNeedInspStart1 && isNeedInspStart2 && (isWK1Ready && isWK2Ready && isWK3Ready) &&

                                RAL.GetSeqStep() != CRail::scMvAuto &&
                                RAL.GetSeqStep() != CRail::scMvPrb  &&
                                !isCycleMvPrb;

        bool isConEnd        = !isNeedInspStart1 || !isNeedInspStart2;

        //Normal Decide Step.
             if (isCycleInsp ) {Trace(m_sPartName.c_str(),"CycleInsp Stt"); Step.iSeq = scInsp ; Step.iCycle = 10 ; PreStep.iCycle = 0 ;} //
        else if (isConEnd    ) {Stat.bWorkEnd = true ; return true ;}
        Stat.bWorkEnd = false ;
    }

    //Cycle.
    switch (Step.iSeq) {
        default    :              /*Trace(m_sPartName.c_str(),"default   End");Step.iSeq = scIdle ;*/  return false ;
        case scInsp: if(CycleInsp()){ Trace(m_sPartName.c_str(),"CycleInsp End");Step.iSeq = scIdle ;} return false ;
    }
}

//One Cycle.
bool CHead::CycleInsp(void) //
{
    //Check Cycle Time Out.
    AnsiString sTemp ;
    if (m_tmCycle.OnDelay(Step.iCycle && Step.iCycle == PreStep.iCycle && CheckStop() && !OM.MstOptn.bDebugMode , 6000 )) {
        EM_SetErr(eiHED_CycleTO);
        sTemp = sTemp.sprintf("%s TIMEOUT STATUS : Step.iCycle=%02d" , __FUNC__ , Step.iCycle );
        Trace(m_sPartName.c_str(),sTemp.c_str());
            //if(!OM.CmnOptn.bVs1Skip) VC.SendReset(vsVisn1) ;
            //if(!OM.CmnOptn.bVs2Skip) VC.SendReset(vsVisn2) ;
            //if(!OM.CmnOptn.bVs3Skip) VC.SendReset(vsVisn3) ;

            if(DM.ARAY[riVS1].GetCntExist())DM.ARAY[riVS1].SetStat(csUnkwn) ;
            if(DM.ARAY[riWR1].GetCntExist())DM.ARAY[riWR1].ChangeStat(csWork,csUnkwn) ;

            if(DM.ARAY[riVS2].GetCntExist())DM.ARAY[riVS2].SetStat(csUnkwn) ;
            if(DM.ARAY[riWR2].GetCntExist())DM.ARAY[riWR2].ChangeStat(csWork,csUnkwn) ;

            if(DM.ARAY[riVS3].GetCntExist())DM.ARAY[riVS3].SetStat(csUnkwn) ;
            if(DM.ARAY[riWR3].GetCntExist())DM.ARAY[riWR3].ChangeStat(csWork,csUnkwn) ;

        Step.iCycle = 0 ;
        return true;
    }
    if(Step.iCycle != PreStep.iCycle) {
        sTemp = sTemp.sprintf("%s Step.iCycle=%02d" , __FUNC__ , Step.iCycle );
        Trace(m_sPartName.c_str(),sTemp.c_str());
    }

    PreStep.iCycle = Step.iCycle ;

    //if(Stat.bReqStop) {
    //    Step.iCycle = 0;
    //    return true ;
    //}

    int r,c ;

    bool r1 , r2 , r3 , r4 ;

    //�޴��� �����߿� ���� �߸� �޴����� �߰��� �����.
    bool bManualInsp = !Step.iSeq ;

    //Cycle.
    switch (Step.iCycle) {

        default : sTemp = sTemp.sprintf("Cycle Default Clear %s Step.iCycle=%02d" , __FUNC__ , Step.iCycle );
                  if(Step.iHome != PreStep.iHome)Trace(m_sPartName.c_str(), sTemp.c_str());
                  Step.iCycle = 0 ;
                  return true ;

        case  10: Step.iCycle++;
                  return false ;

        case  11: MoveMotr(miWRK_YVsn , piWRK_YVsnWork  );
                  MoveMotr(miWRK_XVsn , piWRK_XVsnTrgStt);

                  Step.iCycle++ ;
                  return false ;

        case  12: if(!MoveMotr(miWRK_YVsn,piWRK_YVsnWork  )) return false ;
                  if(!MoveMotr(miWRK_XVsn,piWRK_XVsnTrgStt)) return false ;

                  ResetTrgPos() ; //Ʈ���� ���� Ŭ����
                  Step.iCycle++ ;
                  return false ;

        case  13: if(!IO_GetX(xHED_1Ready)&&!OM.CmnOptn.bVs1Skip){
                      EM_SetErr(eiHED_Visn1NotReady) ;
                      VC.SendReset(vsVisn1) ;
                      if(DM.ARAY[riVS1].GetCntExist())DM.ARAY[riVS1].SetStat(csUnkwn) ;
                      if(DM.ARAY[riWR1].GetCntExist())DM.ARAY[riWR1].ChangeStat(csWork,csUnkwn) ;

                      Step.iCycle = 0 ;
                      return true;
                  }
                  if(!IO_GetX(xHED_2Ready)&&!OM.CmnOptn.bVs2Skip){
                      EM_SetErr(eiHED_Visn2NotReady) ;
                      VC.SendReset(vsVisn2) ;
                      if(DM.ARAY[riVS2].GetCntExist())DM.ARAY[riVS2].SetStat(csUnkwn) ;
                      if(DM.ARAY[riWR2].GetCntExist())DM.ARAY[riWR2].ChangeStat(csWork,csUnkwn) ;

                      Step.iCycle = 0 ;
                      return true;
                  }
                  if(!IO_GetX(xHED_3Ready)&&!OM.CmnOptn.bVs3Skip){
                      EM_SetErr(eiHED_Visn3NotReady) ;
                      VC.SendReset(vsVisn3) ;
                      if(DM.ARAY[riVS3].GetCntExist())DM.ARAY[riVS3].SetStat(csUnkwn) ;
                      if(DM.ARAY[riWR3].GetCntExist())DM.ARAY[riWR3].ChangeStat(csWork,csUnkwn) ;

                      Step.iCycle = 0 ;
                      return true;
                  }

                  SetTrgPos(); //Ʈ���� ����.
                  MoveMotr(miWRK_XVsn,piWRK_XVsnTrgEnd );
                  //MT_GoAbsRun(miWRK_XVsn , 13 ) ;
                  Step.iCycle++ ;
                  return false ;

        case  14: if(!MoveMotr(miWRK_XVsn,piWRK_XVsnTrgEnd )) return false ;
                  ResetTrgPos() ; //Ʈ���� ���� Ŭ����
                  Step.iCycle++ ;
                  return false ;

        case  15: FindChip(r , c ) ;
        //�̼��� ȣ�Ͼȵ� �� �����...�н�...
                  //r = OM.DevInfo.iRowCnt - r/OM.DevInfo.iRowInspCnt * OM.DevInfo.iRowInspCnt -1;

                  for(c = 0 ; c < DM.ARAY[riVS1].GetMaxCol() ; c++ ) {
                      for(int i = 0 ; i < OM.DevInfo.iRowInspCnt ; i ++) {
                          if(DM.ARAY[riVS1].CheckAllExist())DM.ARAY[riVS1].SetStat(r-i,c,csWork) ;
                          if(DM.ARAY[riVS2].CheckAllExist())DM.ARAY[riVS2].SetStat(r-i,c,csWork) ;
                          if(DM.ARAY[riVS3].CheckAllExist())DM.ARAY[riVS3].SetStat(r-i,c,csWork) ;
                      }
                  }

                  r1 = DM.ARAY[riVS1].GetCntStat(csUnkwn);
                  r2 = DM.ARAY[riVS2].GetCntStat(csUnkwn);
                  r3 = DM.ARAY[riVS3].GetCntStat(csUnkwn);


                  //Stat.bReqAllInsp = true ;
                  if(r1 || r2 || r3) {
                      Step.iCycle=11 ; //Next Row Insp
                      return false ;

                  }
                  Step.iCycle++ ;
                  return false ;

        case  16: //�ѽ�Ʈ���� �� �˻����� ���.
                  MoveMotr(miWRK_YVsn,piWRK_YVsnWait) ;
                  Step.iCycle++ ;
                  return false ;

        //17 Step Used When TimeOut
        case  17: if(!MoveMotr(miWRK_YVsn,piWRK_YVsnWait)) return false ;
                  MoveMotr(miWRK_XVsn , piWRK_XVsnWait  ) ;
        
                  Step.iCycle++ ;
                  return false ;

        //17 Step Used When TimeOut
        case  18: //if(!MoveMotr(miWRK_XVsn , piWRK_XVsnWait)) return false;  //���߿� �����ؾ� ��... ��Ÿ�Ӷ����� ����� ���� ����..JS
                  if(!OM.CmnOptn.bVs1Skip && !IO_GetX(xHED_1Result)) return false ;
                  if(!OM.CmnOptn.bVs2Skip && !IO_GetX(xHED_2Result)) return false ;
                  if(!OM.CmnOptn.bVs3Skip && !IO_GetX(xHED_3Result)) return false ;

                  VC.ClearErrCnt();

                  //Vision 1
                  if(OM.CmnOptn.bVs1Skip) {
                      if(DM.ARAY[riWR1].CheckAllExist())DM.ARAY[riWR1].ChangeStat(csUnkwn,csWork) ;
                  }
                  else {
                      if(DM.ARAY[riWR1].CheckAllExist()){
                          HED.DpAray1.SetStat(csWork);
                          /*iVs1FailCnt =*/
                          VC.SimpleReadResult(1,&HED.DpAray1);
                          if(!VC.ReadResult(1,riWR1)){ //���� ������ �о� ����.
                              if(!bManualInsp)EM_SetErr(eiHED_Visn1Read);
                              DM.ARAY[riVS1].SetStat(csUnkwn) ;
                              if(DM.ARAY[riVS2].GetCntExist()) DM.ARAY[riVS2].SetStat(csUnkwn) ;
                              if(DM.ARAY[riVS3].GetCntExist()) DM.ARAY[riVS3].SetStat(csUnkwn) ;
                              //VC.SendReset(vsVisn1); //�����带 �Ѽ� ���� ���V.
                              //if(!OM.CmnOptn.bVs2Skip) VC.SendReset(vsVisn2) ;
                              //if(!OM.CmnOptn.bVs3Skip) VC.SendReset(vsVisn3) ;
                              Step.iCycle=0 ;
                              return true ;
                          }
                      }
                  }

                  //Vision2
                  if(OM.CmnOptn.bVs2Skip) {
                      if(DM.ARAY[riWR2].CheckAllExist())DM.ARAY[riWR2].ChangeStat(csUnkwn,csWork) ;
                  }
                  else{
                      if(DM.ARAY[riWR2].CheckAllExist() ){ //���� ���׿�.�ؿ���.
                          HED.DpAray2.SetStat(csWork);

                          /*iVs2FailCnt =*/
                          VC.SimpleReadResult(2,&HED.DpAray2);
                          if(!VC.ReadResult(2,riWR2)){
                              if(!bManualInsp)EM_SetErr(eiHED_Visn2Read);
                              if(DM.ARAY[riVS1].GetCntExist()) DM.ARAY[riVS1].SetStat(csUnkwn) ;
                              DM.ARAY[riVS2].SetStat(csUnkwn) ;
                              if(DM.ARAY[riVS3].GetCntExist()) DM.ARAY[riVS3].SetStat(csUnkwn) ;
                              //VC.SendReset(vsVisn2); //�����带 �Ѽ� ���� ���V.
                              //if(!OM.CmnOptn.bVs1Skip) VC.SendReset(vsVisn1) ;
                              //if(!OM.CmnOptn.bVs3Skip) VC.SendReset(vsVisn3) ;
                              Step.iCycle=0 ;
                              return true ;
                          }
                      }
                  }

                  //Vision3
                  if(OM.CmnOptn.bVs3Skip) {
                      if(DM.ARAY[riWR3].CheckAllExist())DM.ARAY[riWR3].ChangeStat(csUnkwn,csWork) ;
                  }
                  else {
                      if(DM.ARAY[riWR3].CheckAllExist() ){
                          HED.DpAray3.SetStat(csWork);

                          /*iVs3FailCnt =*/
                          VC.SimpleReadResult(3,&HED.DpAray3);
                          if(!VC.ReadResult(3,riWR3)){
                              if(!bManualInsp)EM_SetErr(eiHED_Visn3Read);
                              if(DM.ARAY[riVS1].GetCntExist()) DM.ARAY[riVS1].SetStat(csUnkwn) ;
                              if(DM.ARAY[riVS2].GetCntExist()) DM.ARAY[riVS2].SetStat(csUnkwn) ;
                              DM.ARAY[riVS3].SetStat(csUnkwn) ;
                              //VC.SendReset(vsVisn3); //�����带 �Ѽ� ���� ���V.
                              //if(!OM.CmnOptn.bVs1Skip) VC.SendReset(vsVisn1) ;
                              //if(!OM.CmnOptn.bVs2Skip) VC.SendReset(vsVisn2) ;
                              Step.iCycle=0 ;
                              return true ;
                          }
                      }
                  }


                  Step.iCycle=0 ;
                  return true  ;
    }
}

void CHead::SetLastCmd()
{
    return ; //����Ʈ�� �ʿ� ����.

}

bool CHead::CheckMoved()
{
    return true ; //����Ʈ�� �ʿ� ����.
}

bool CHead::CheckStop()
{
    if(!MT_GetStop(miWRK_YVsn)) return false ;
    if(!MT_GetStop(miWRK_XVsn)) return false ;

    return true ;
}

void CHead::Load(bool IsLoad)
{
    //Local Var.
    TUserINI   UserINI;
    AnsiString sPath  ;

    //Set Dir.
    sPath = EXE_FOLDER + "SeqData\\" + m_sPartName.Trim() +".INI";

    //Load Device.
    Trace( "CHead","`Load Start") ;

    if(IsLoad) {
        //UserINI.Load(sPath.c_str()  , m_sPartName.c_str()  , "iVs1FailCnt " , iVs1FailCnt   );
        //UserINI.Load(sPath.c_str()  , m_sPartName.c_str()  , "iVs2FailCnt " , iVs2FailCnt   );
        //UserINI.Load(sPath.c_str()  , m_sPartName.c_str()  , "iVs3FailCnt " , iVs3FailCnt   );

    }
    else {
        //UserINI.Save(sPath.c_str()  , m_sPartName.c_str()  , "iVs1FailCnt " , iVs1FailCnt   );
        //UserINI.Save(sPath.c_str()  , m_sPartName.c_str()  , "iVs2FailCnt " , iVs2FailCnt   );
        //UserINI.Save(sPath.c_str()  , m_sPartName.c_str()  , "iVs3FailCnt " , iVs3FailCnt   );
    }
    Trace( "CHead","Load End") ;
}
















