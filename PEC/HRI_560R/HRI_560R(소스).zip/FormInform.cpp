//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FormInform.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmInform *FrmInform;
//---------------------------------------------------------------------------
__fastcall TFrmInform::TFrmInform(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------









