//---------------------------------------------------------------------------

#ifndef FormRsltBigH
#define FormRsltBigH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrmRsltBig : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TLabel *Label16;
        TLabel *Label17;
        TEdit *edLotNo;
        TEdit *edFail;
        TEdit *edRslt1;
        TEdit *edRslt2;
        TEdit *edRslt3;
        TEdit *edRslt4;
        TEdit *edRslt5;
        TEdit *edRslt6;
        TEdit *edRslt7;
        TEdit *edRslt8;
        TEdit *edRslt9;
        TEdit *edRslt10;
        TEdit *edRslt11;
        TEdit *edRslt12;
        TEdit *edRslt13;
        TEdit *edRslt14;
        TEdit *edWork;
        TLabel *Label18;
        TEdit *edTime;
        TLabel *Label19;
        TEdit *edFailTotal;
        TLabel *Label44;
        TLabel *Label45;
        TLabel *Label46;
        TLabel *Label47;
        TLabel *Label48;
        TLabel *Label50;
        TLabel *Label51;
        TLabel *Label52;
        TLabel *Label53;
        TLabel *Label54;
        TLabel *Label55;
        TLabel *Label56;
        TLabel *Label57;
        TLabel *Label58;
        TLabel *Label59;
        TLabel *Label20;
private:	// User declarations
public:		// User declarations
        __fastcall TFrmRsltBig(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmRsltBig *FrmRsltBig;
//---------------------------------------------------------------------------
#endif
